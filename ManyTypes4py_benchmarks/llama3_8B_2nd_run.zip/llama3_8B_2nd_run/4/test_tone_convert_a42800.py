from __future__ import unicode_literals
from pytest import mark
from pypinyin import pinyin_dict
from pypinyin.contrib.tone_convert import (
    tone_to_normal,
    tone_to_tone2,
    tone2_to_tone,
    tone_to_tone3,
    tone3_to_tone,
    tone2_to_normal,
    tone2_to_tone3,
    tone3_to_tone2,
    tone3_to_normal,
    to_normal,
    to_tone,
    to_tone2,
    to_tone3,
    to_initials,
    to_finals,
    to_finals_tone,
    to_finals_tone2,
    to_finals_tone3
)

@mark.parametrize('pinyin, result', ...)
def test_tone_to_normal(pinyin: str, result: str) -> None:
    ...

@mark.parametrize('pinyin, v_to_u, result', ...)
def test_tone_to_normal_with_v_to_u(pinyin: str, v_to_u: bool, result: str) -> None:
    ...

@mark.parametrize('pinyin, result', ...)
def test_tone_tone2(pinyin: str, result: str) -> None:
    ...

@mark.parametrize('pinyin, neutral_tone_with_five, result', ...)
def test_tone_tone2_with_neutral_tone_with_five(pinyin: str, neutral_tone_with_five: bool, result: str) -> None:
    ...

@mark.parametrize('pinyin, v_to_u, result', ...)
def test_tone_tone2_with_v_to_u(pinyin: str, v_to_u: bool, result: str) -> None:
    ...

@mark.parametrize('pinyin, result', ...)
def test_tone_tone3(pinyin: str, result: str) -> None:
    ...

@mark.parametrize('pinyin, neutral_tone_with_five, result', ...)
def test_tone_tone3_with_neutral_tone_with_five(pinyin: str, neutral_tone_with_five: bool, result: str) -> None:
    ...

@mark.parametrize('pinyin, v_to_u, result', ...)
def test_tone_tone3_with_v_to_u(pinyin: str, v_to_u: bool, result: str) -> None:
    ...

@mark.parametrize('pinyin, result', ...)
def test_tone2_to_normal(pinyin: str, result: str) -> None:
    ...

@mark.parametrize('pinyin, v_to_u, result', ...)
def test_tone2_to_normal_with_v_to_u(pinyin: str, v_to_u: bool, result: str) -> None:
    ...

@mark.parametrize('pinyin, result', ...)
def test_tone3_to_normal(pinyin: str, result: str) -> None:
    ...

@mark.parametrize('pinyin, v_to_u, result', ...)
def test_tone3_to_normal_with_v_to_u(pinyin: str, v_to_u: bool, result: str) -> None:
    ...

@mark.parametrize('pinyin, result', ...)
def test_tone3_to_tone2(pinyin: str, result: str) -> None:
    ...

@mark.parametrize('pinyin, v_to_u, result', ...)
def test_tone3_to_tone2_with_v_to_u(pinyin: str, v_to_u: bool, result: str) -> None:
    ...

@mark.parametrize('pinyin, strict, result', ...)
def test_to_initials(pinyin: str, strict: bool, result: str) -> None:
    ...

@mark.parametrize('pinyin, strict, v_to_u, result', ...)
def test_to_finals(pinyin: str, strict: bool, v_to_u: bool, result: str) -> None:
    ...

@mark.parametrize('pinyin, strict, result', ...)
def test_to_finals_tone(pinyin: str, strict: bool, result: str) -> None:
    ...

@mark.parametrize('pinyin, strict, v_to_u, neutral_tone_with_five, result', ...)
def test_to_finals_tone2(pinyin: str, strict: bool, v_to_u: bool, neutral_tone_with_five: bool, result: str) -> None:
    ...

@mark.parametrize('pinyin, strict, v_to_u, neutral_tone_with_five, result', ...)
def test_to_finals_tone3(pinyin: str, strict: bool, v_to_u: bool, neutral_tone_with_five: bool, result: str) -> None:
    ...

@mark.parametrize('input', ...)
def test_tone_to_tone2_tone3_to_tone(input: str) -> None:
    ...

@mark.parametrize('input', ...)
def test_issue_290_1(input: str) -> None:
    ...

@mark.parametrize('input', ...)
def test_issue_290_2(input: str) -> None:
    ...

@mark.parametrize('input', ...)
def test_issue_290_3(input: str) -> None:
    ...

@mark.parametrize('input', ...)
def test_issue_290_4(input: str) -> None:
    ...
