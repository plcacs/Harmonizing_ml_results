from __future__ import annotations
from typing import cast

def time_string(i):
    """Return a formatted ramp rate time string."""
    if i >= 60:
        return f'{float(i) / 60:.1f} {UnitOfTime.MINUTES}'
    return f'{i} {UnitOfTime.SECONDS}'
RAMP_RATE_OPTIONS = [time_string(rate) for rate in INSTEON_RAMP_RATES.values()]
BACKLIGHT_MEMORY_FILTER = {'memory': DEV_BL_ADDR, 'cmd1': DEV_CMD_MEMORY_WRITE}

async def async_setup_entry(hass: HomeAssistant, config_entry: ConfigEntry, async_add_entities: AddConfigEntryEntitiesCallback):
    """Set up ISY/IoX select entities from config entry."""
    isy_data = hass.data[DOMAIN][config_entry.entry_id]
    device_info = isy_data.devices
    entities = []
    for node, control in isy_data.aux_properties[Platform.SELECT]:
        name = COMMAND_FRIENDLY_NAME.get(control, control).replace('_', ' ').title()
        if node.address != node.primary_node:
            name = f'{node.name} {name}'
        options = []
        if control == PROP_RAMP_RATE:
            options = RAMP_RATE_OPTIONS
        elif control == CMD_BACKLIGHT:
            options = BACKLIGHT_INDEX
        elif (uom := (node.aux_properties[control].uom == UOM_INDEX)):
            if (options_dict := UOM_TO_STATES.get(uom)):
                options = list(options_dict.values())
        description = SelectEntityDescription(key=f'{node.address}_{control}', name=name, entity_category=EntityCategory.CONFIG, options=options)
        entity_detail = {'node': node, 'control': control, 'unique_id': f'{isy_data.uid_base(node)}_{control}', 'description': description, 'device_info': device_info.get(node.primary_node)}
        if control == PROP_RAMP_RATE:
            entities.append(ISYRampRateSelectEntity(**entity_detail))
            continue
        if control == CMD_BACKLIGHT:
            entities.append(ISYBacklightSelectEntity(**entity_detail))
            continue
        if node.uom == UOM_INDEX and options:
            entities.append(ISYAuxControlIndexSelectEntity(**entity_detail))
            continue
        _LOGGER.debug('ISY missing node index unit definitions for %s: %s', node.name, name)
    async_add_entities(entities)

class ISYRampRateSelectEntity(ISYAuxControlEntity, SelectEntity):
    """Representation of a ISY/IoX Aux Control Ramp Rate Select entity."""
    @property
    def current_option(self) -> str | None:
        """Return the selected entity option to represent the entity state."""
        node_prop = self._node.aux_properties[self._control]
        if node_prop.value == ISY_VALUE_UNKNOWN:
            return None
        return RAMP_RATE_OPTIONS[int(node_prop.value)]

    async def async_select_option(self, option: str):
        """Change the selected option."""
        await self._node.set_ramp_rate(RAMP_RATE_OPTIONS.index(option))

class ISYAuxControlIndexSelectEntity(ISYAuxControlEntity, SelectEntity):
    """Representation of a ISY/IoX Aux Control Index Select entity."""
    @property
    def current_option(self) -> str | None:
        """Return the selected entity option to represent the entity state."""
        node_prop = self._node.aux_properties[self._control]
        if node_prop.value == ISY_VALUE_UNKNOWN:
            return None
        if (options_dict := UOM_TO_STATES.get(node_prop.uom)):
            return cast(str, options_dict.get(node_prop.value, node_prop.value))
        return cast(str, node_prop.formatted)

    async def async_select_option(self, option: str):
        """Change the selected option."""
        node_prop = self._node.aux_properties[self._control]
        await self._node.send_cmd(self._control, val=self.options.index(option), uom=node_prop.uom)

class ISYBacklightSelectEntity(ISYAuxControlEntity, SelectEntity, RestoreEntity):
    """Representation of a ISY/IoX Backlight Select entity."""
    _assumed_state: bool = True

    def __init__(self, node: Node, control: str, unique_id: str, description: SelectEntityDescription, device_info: DeviceInfo):
        """Initialize the ISY Backlight Select entity."""
        super().__init__(node, control, unique_id, description, device_info)
        self._memory_change_handler = None
        self._attr_current_option: str | None = None

    async def async_added_to_hass(self) -> None:
        """Load the last known state when added to hass."""
        await super().async_added_to_hass()
        if (last_state := (await self.async_get_last_state())) and last_state.state not in (STATE_UNKNOWN, STATE_UNAVAILABLE):
            self._attr_current_option = last_state.state
        self._memory_change_handler = self._node.isy.nodes.status_events.subscribe(self.async_on_memory_write, event_filter={TAG_ADDRESS: self._node.address, ATTR_ACTION: DEV_MEMORY}, key=self.unique_id)

    @callback
    def async_on_memory_write(self, event: NodeChangedEvent, key: str):
        """Handle a memory write event from the ISY Node."""
        if not BACKLIGHT_MEMORY_FILTER.items() <= event.event_info.items():
            return
        option = BACKLIGHT_INDEX[event.event_info['value']]
        if option == self._attr_current_option:
            return
        self._attr_current_option = option
        self.async_write_ha_state()

    async def async_select_option(self, option: str):
        """Change the selected option."""
        if not await self._node.send_cmd(CMD_BACKLIGHT, val=BACKLIGHT_INDEX.index(option), uom=ISY_UOM_INDEX):
            raise HomeAssistantError(f'Could not set backlight to {option} for {self._node.address}')
        self._attr_current_option = option
        self.async_write_ha_state()
