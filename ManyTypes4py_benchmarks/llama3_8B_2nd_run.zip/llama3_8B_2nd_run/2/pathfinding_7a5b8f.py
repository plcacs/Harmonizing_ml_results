import json
import random
from dataclasses import dataclass
from datetime import datetime
from json import JSONDecodeError
from typing import Union
from urllib.parse import urlparse
from uuid import UUID
import click
import gevent
import structlog
from eth_utils import decode_hex, to_canonical_address, to_hex
from requests.exceptions import RequestException
from requests.sessions import Session
from web3 import Web3
from raiden.constants import DEFAULT_HTTP_REQUEST_TIMEOUT, MATRIX_AUTO_SELECT_SERVER, PFS_PATHS_REQUEST_TIMEOUT, ZERO_TOKENS, RoutingMode
from raiden.exceptions import PFSError, PFSReturnedError, RaidenError, ServiceRequestFailed, ServiceRequestIOURejected
from raiden.messages.metadata import RouteMetadata
from raiden.network.proxies.service_registry import ServiceRegistry
from raiden.network.utils import get_response_json
from raiden.utils.formatting import to_checksum_address
from raiden.utils.http import TimeoutHTTPAdapter
from raiden.utils.signer import LocalSigner
from raiden.utils.system import get_system_spec
from raiden.utils.transfers import to_rdn
from raiden.utils.typing import Address, AddressMetadata, Any, BlockExpiration, BlockIdentifier, BlockNumber, BlockTimeout, ChainID, Dict, InitiatorAddress, List, OneToNAddress, Optional, PaymentAmount, PrivateKey, Signature, TargetAddress, TokenAmount, TokenNetworkAddress, TokenNetworkRegistryAddress, Tuple

@dataclass(frozen=True)
class PFSInfo:
    pass

@dataclass
class PFSConfig:
    pass

@dataclass
class IOU:
    signature: Optional[Signature] = None

    def sign(self, privkey: PrivateKey) -> None:
        self.signature = Signature(sign_one_to_n_iou(privatekey=privkey, sender=to_checksum_address(self.sender), receiver=to_checksum_address(self.receiver), amount=self.amount, expiration_block=self.expiration_block, one_to_n_address=to_checksum_address(self.one_to_n_address), chain_id=self.chain_id))

    def as_json(self) -> Dict[str, Any]:
        data = dict(sender=to_checksum_address(self.sender), receiver=to_checksum_address(self.receiver), one_to_n_address=to_checksum_address(self.one_to_n_address), amount=self.amount, expiration_block=self.expiration_block, chain_id=self.chain_id)
        if self.signature is not None:
            data['signature'] = to_hex(self.signature)
        return data

USER_AGENT_STR: str = 'Raiden/{raiden}/DB:{raiden_db_version}/{python_implementation}/{python_version}/{system}/{architecture}/{distribution}'.format(**get_system_spec()).replace(' ', '-')

session: Session = Session()
session.headers['User-Agent'] = USER_AGENT_STR
timeout_adapter: TimeoutHTTPAdapter = TimeoutHTTPAdapter(timeout=DEFAULT_HTTP_REQUEST_TIMEOUT)
session.mount('http://', timeout_adapter)
session.mount('https://', timeout_adapter)

MAX_PATHS_QUERY_ATTEMPTS: int = 2

def get_pfs_info(url: str) -> PFSInfo:
    try:
        response = session.get(f'{url}/api/v1/info')
        infos: Dict[str, Any] = get_response_json(response)
        matrix_server_info: urlparse = urlparse(infos['matrix_server'])
        return PFSInfo(url=url, price=infos['price_info'], chain_id=infos['network_info']['chain_id'], token_network_registry_address=TokenNetworkRegistryAddress(to_canonical_address(infos['network_info']['token_network_registry_address'])), user_deposit_address=Address(to_canonical_address(infos['network_info']['user_deposit_address'])), payment_address=to_canonical_address(infos['payment_address']), message=infos['message'], operator=infos['operator'], version=infos['version'], confirmed_block_number=infos['network_info']['confirmed_block']['number'], matrix_server=matrix_server_info.netloc)
    except RequestException as e:
        msg: str = 'Selected Pathfinding Service did not respond'
        raise ServiceRequestFailed(msg) from e
    except (json.JSONDecodeError, KeyError, ValueError) as e:
        msg: str = 'Selected Pathfinding Service returned unexpected reply'
        raise ServiceRequestFailed(msg) from e

def get_valid_pfs_url(service_registry: ServiceRegistry, index_in_service_registry: int, block_identifier: BlockIdentifier, pathfinding_max_fee: PaymentAmount) -> Optional[str]:
    """Returns the URL for the PFS identified by the given index

    Checks validity of registration in the ServiceRegistry contract and
    checks the price from the PFS' info endpoint.

    Returns PFS URL or None (if any check fails).
    """
    address: Address = service_registry.ever_made_deposits(block_identifier=block_identifier, index=index_in_service_registry)
    if not address:
        return None
    if not service_registry.has_valid_registration(service_address=address, block_identifier=block_identifier):
        return None
    url: str = service_registry.get_service_url(block_identifier=block_identifier, service_address=address)
    if not url:
        return None
    try:
        pfs_info: PFSInfo = get_pfs_info(url)
    except ServiceRequestFailed:
        return None
    if pfs_info.price > pathfinding_max_fee:
        return None
    return url

def get_random_pfs(service_registry: ServiceRegistry, block_identifier: BlockIdentifier, pathfinding_max_fee: PaymentAmount) -> Tuple[Optional[str], Optional[Address]]:
    """Selects a random PFS from service_registry.

    Returns a tuple of the chosen services url and eth address.
    If there are no PFS in the given registry, it returns (None, None).
    """
    number_of_addresses: int = service_registry.ever_made_deposits_len(block_identifier=block_identifier)
    indices_to_try: List[int] = list(range(number_of_addresses))
    random.shuffle(indices_to_try)
    while indices_to_try:
        index: int = indices_to_try.pop()
        url: Optional[str] = get_valid_pfs_url(service_registry=service_registry, index_in_service_registry=index, block_identifier=block_identifier, pathfinding_max_fee=pathfinding_max_fee)
        if url:
            return url, service_registry.ever_made_deposits(block_identifier=block_identifier, index=index)
    return None, None

def configure_pfs_or_exit(pfs_url: str, routing_mode: RoutingMode, service_registry: ServiceRegistry, node_chain_id: ChainID, token_network_registry_address: TokenNetworkRegistryAddress, pathfinding_max_fee: PaymentAmount) -> PFSInfo:
    """
    Take in the given pfs_address argument, the service registry and find out a
    pfs address to use.

    If pfs_url is provided we use that.
    If pfs_url is 'auto' then we randomly choose a PFS address from the registry
    """
    msg: str = 'Invalid code path; configure_pfs needs routing mode PFS'
    assert routing_mode is RoutingMode.PFS, msg
    msg = "With PFS routing mode we shouldn't get to configure_pfs with pfs_address being None"
    assert pfs_url, msg
    if pfs_url == MATRIX_AUTO_SELECT_SERVER:
        if service_registry is None:
            raise RaidenError("Raiden was started with routing mode set to PFS, the pathfinding service address set to 'auto' but no service registry address was given. Either specifically provide a PFS address or provide a service registry address.")
        block_hash: BlockIdentifier = service_registry.client.get_confirmed_blockhash()
        maybe_pfs_url: Optional[str] = get_random_pfs(service_registry=service_registry, block_identifier=block_hash, pathfinding_max_fee=pathfinding_max_fee)
        if maybe_pfs_url is None:
            raise RaidenError('Can not find any registered pathfinding service and basic routing is not used.')
        else:
            pfs_url = maybe_pfs_url
    try:
        pathfinding_service_info: PFSInfo = get_pfs_info(pfs_url)
    except ServiceRequestFailed as e:
        raise RaidenError(f'There was an error with the Pathfinding Service with address {pfs_url}. Raiden will shut down. Please try a different Pathfinding Service. \nError Message: {str(e)}')
    if pathfinding_service_info.price > 0 and (not pathfinding_service_info.payment_address):
        raise RaidenError(f'The Pathfinding Service at {pfs_url} did not provide a payment address. Raiden will shut down. Please try a different Pathfinding Service.')
    if node_chain_id != pathfinding_service_info.chain_id:
        raise RaidenError(f'Invalid reply from Pathfinding Service {pfs_url}\nPathfinding Service is not operating on the same network ({pathfinding_service_info.chain_id}) as your node is ({node_chain_id}).\nRaiden will shut down. Please choose a different Pathfinding Service.')
    if pathfinding_service_info.token_network_registry_address != token_network_registry_address:
        raise RaidenError(f'Invalid reply from Pathfinding Service {pfs_url}Pathfinding Service is not operating on the same Token Network Registry ({to_checksum_address(pathfinding_service_info.token_network_registry_address)}) as your node ({to_checksum_address(token_network_registry_address)}).\nRaiden will shut down. Please choose a different Pathfinding Service.')
    click.secho(f'You have chosen the Pathfinding Service at {pfs_url}.\nOperator: {pathfinding_service_info.operator}, running version: {pathfinding_service_info.version}, chain_id: {pathfinding_service_info.chain_id}.\nFees will be paid to {to_checksum_address(pathfinding_service_info.payment_address)}. Each request costs {to_rdn(pathfinding_service_info.price)} RDN.\nMessage from the Pathfinding Service:\n{pathfinding_service_info.message}')
    log.info('Using Pathfinding Service', pfs_info=pathfinding_service_info)
    return pathfinding_service_info

def check_pfs_for_production(service_registry: ServiceRegistry, pfs_info: PFSInfo) -> None:
    """Checks that the PFS in `pfs_info` is registered in the service registry
    and that the URL matches.

    Should only be called in production mode.
    """
    if service_registry is None:
        raise RaidenError('Cannot verify registration of Pathfinding Service because no Service Registry is set. Raiden will shut down. Please select a Service Registry.')
    pfs_registered: bool = service_registry.has_valid_registration(block_identifier=service_registry.client.get_confirmed_blockhash(), service_address=pfs_info.payment_address)
    registered_pfs_url: Optional[str] = service_registry.get_service_url(block_identifier=service_registry.client.get_confirmed_blockhash(), service_address=pfs_info.payment_address)
    pfs_url_matches: bool = registered_pfs_url == pfs_info.url
    if not (pfs_registered and pfs_url_matches):
        raise RaidenError(f"The Pathfinding Service at {pfs_info.url} is not registered with the Service Registry at {to_checksum_address(service_registry.address)} or the registered URL ({registered_pfs_url}) doesn't match the given URL {pfs_info.url}. Raiden will shut down. Please select a registered Pathfinding Service.")

def get_last_iou(url: str, token_network_address: TokenNetworkAddress, sender: Address, receiver: Address, privkey: PrivateKey) -> Optional[IOU]:
    timestamp: str = datetime.utcnow().isoformat(timespec='seconds')
    signature_data: bytes = sender + receiver + Web3.toBytes(text=timestamp)
    signature: Optional[Signature] = Signature(to_hex(LocalSigner(privkey).sign(signature_data)))
    try:
        response = session.get(f'{url}/api/v1/{to_checksum_address(token_network_address)}/payment/iou', params=dict(sender=to_checksum_address(sender), receiver=to_checksum_address(receiver), timestamp=timestamp, signature=to_hex(signature)))
        data: Dict[str, Any] = json.loads(response.content)
        if data is None:
            return None
        return IOU(sender=to_canonical_address(data['sender']), receiver=to_canonical_address(data['receiver']), one_to_n_address=OneToNAddress(to_canonical_address(data['one_to_n_address'])), amount=data['amount'], expiration_block=data['expiration_block'], chain_id=data['chain_id'], signature=Signature(decode_hex(data['signature'])))
    except (RequestException, ValueError, KeyError) as e:
        raise ServiceRequestFailed(str(e))

def make_iou(pfs_config: PFSConfig, our_address: Address, one_to_n_address: OneToNAddress, privkey: PrivateKey, block_number: BlockNumber, chain_id: ChainID, offered_fee: PaymentAmount) -> IOU:
    expiration: BlockExpiration = BlockExpiration(block_number + pfs_config.iou_timeout)
    iou: IOU = IOU(sender=our_address, receiver=pfs_config.info.payment_address, one_to_n_address=one_to_n_address, amount=offered_fee, expiration_block=expiration, chain_id=chain_id)
    iou.sign(privkey)
    return iou

def update_iou(iou: IOU, privkey: PrivateKey, added_amount: PaymentAmount = ZERO_TOKENS, expiration_block: Optional[BlockNumber] = None) -> IOU:
    expected_signature: Signature = Signature(sign_one_to_n_iou(privatekey=privkey, sender=to_checksum_address(iou.sender), receiver=to_checksum_address(iou.receiver), amount=iou.amount, expiration_block=iou.expiration_block, one_to_n_address=to_checksum_address(iou.one_to_n_address), chain_id=iou.chain_id))
    if iou.signature != expected_signature:
        raise ServiceRequestFailed('Last IOU as given by the Pathfinding Service is invalid (signature does not match)')
    iou.amount = TokenAmount(iou.amount + added_amount)
    if expiration_block:
        iou.expiration_block = expiration_block
    iou.sign(privkey)
    return iou

def create_current_iou(pfs_config: PFSConfig, token_network_address: TokenNetworkAddress, one_to_n_address: OneToNAddress, our_address: Address, privkey: PrivateKey, block_number: BlockNumber, chain_id: ChainID, offered_fee: PaymentAmount, scrap_existing_iou: bool = False) -> IOU:
    latest_iou: Optional[IOU] = None
    if not scrap_existing_iou:
        latest_iou = get_last_iou(url=pfs_config.info.url, token_network_address=token_network_address, sender=our_address, receiver=pfs_config.info.payment_address, privkey=privkey)
    if latest_iou is None:
        return make_iou(pfs_config=pfs_config, our_address=our_address, one_to_n_address=one_to_n_address, privkey=privkey, block_number=block_number, chain_id=chain_id, offered_fee=offered_fee)
    else:
        added_amount: PaymentAmount = offered_fee
        return update_iou(iou=latest_iou, privkey=privkey, added_amount=added_amount)

def post_pfs_paths(routing_mode: RoutingMode, pfs_config: PFSConfig, token_network_address: TokenNetworkAddress, route: List[Address], token: bytes, successful: bool) -> None:
    feedback_disabled: bool = routing_mode == RoutingMode.PRIVATE or pfs_config is None
    if feedback_disabled:
        return
    hex_route: List[str] = [to_checksum_address(address) for address in route]
    payload: Dict[str, Any] = dict(token=token.hex, path=hex_route, success=successful)
    log.info('Sending routing feedback to Pathfinding Service', url=pfs_config.info.url, token_network_address=to_checksum_address(token_network_address), payload=payload)
    try:
        session.post(f'{pfs_config.info.url}/api/v1/{to_checksum_address(token_network_address)}/feedback', json=payload)
    except RequestException as e:
        log.warning('Could not send feedback to Pathfinding Service', exception_=str(e), payload=payload)

class PFSProxy:
    def __init__(self, pfs_config: PFSConfig) -> None:
        self._pfs_config: PFSConfig = pfs_config

    def query_address_metadata(self, address: Address) -> AddressMetadata:
        return _query_address_metadata(self._pfs_config, address)

    def query_paths(self, our_address: Address, privkey: PrivateKey, current_block_number: BlockNumber, token_network_address: TokenNetworkAddress, one_to_n_address: OneToNAddress, chain_id: ChainID, route_from: Address, route_to: Address, value: PaymentAmount, pfs_wait_for_block: BlockNumber) -> Tuple[List[Address], Optional[bytes]]:
        return _query_paths(self._pfs_config, our_address=our_address, privkey=privkey, current_block_number=current_block_number, token_network_address=token_network_address, one_to_n_address=one_to_n_address, chain_id=chain_id, route_from=route_from, route_to=route_to, value=value, pfs_wait_for_block=pfs_wait_for_block)

post_pfs_feedback(routing_mode: RoutingMode, pfs_config: PFSConfig, token_network_address: TokenNetworkAddress, route: List[Address], token: bytes, successful: bool) -> None:
    feedback_disabled: bool = routing_mode == RoutingMode.PRIVATE or pfs_config is None
    if feedback_disabled:
        return
    hex_route: List[str] = [to_checksum_address(address) for address in route]
    payload: Dict[str, Any] = dict(token=token.hex, path=hex_route, success=successful